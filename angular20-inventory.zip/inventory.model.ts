export interface Inventory {
  _id?: string;
  id?: string;
  email: string;
  name: string;
  quantity: number | string;
  batchId: string;
  expireDate: string;
  price: number | string;
  imagePath?: string;
  category?: string;
  supplier?: string;
  status?: 'In Stock' | 'Low Stock' | 'Out Of Stock';
}
