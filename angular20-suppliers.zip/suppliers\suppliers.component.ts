import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { SupplierService } from '../../services/supplier.service';
import { Supplier } from '../../services/supplier.model';

@Component({
  selector: 'app-suppliers',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './suppliers.component.html',
  styleUrls: ['./suppliers.component.css']
})
export class SuppliersComponent implements OnInit {
  loading = false;
  searchText = '';
  selectedSupplier: Supplier | null = null;
  suppliers: Supplier[] = [];
  filteredSuppliers: Supplier[] = [];
  supplierForm!: FormGroup;
  errorMessage = '';
  successMessage = '';
  isEditing = false;

  constructor(private fb: FormBuilder, private supplierService: SupplierService) {}

  ngOnInit(): void {
    this.buildForm();
    this.loadSuppliers();
  }

  buildForm(): void {
    this.supplierForm = this.fb.group({
      supplierId: ['', [Validators.required, Validators.minLength(3)]],
      name: ['', [Validators.required, Validators.minLength(2)]],
      email: ['', [Validators.required, Validators.email]],
      contact: ['', [Validators.required, Validators.pattern(/^\d{10}$/)]],
      address: ['', Validators.required],
      company: ['', Validators.required],
      drugs: ['', Validators.required],
      status: ['Active', Validators.required]
    });
  }

  get f() {
    return this.supplierForm.controls;
  }

  searchSupplier(): void {
    const value = this.searchText.toLowerCase().trim();

    if (!value) {
      this.filteredSuppliers = [...this.suppliers];
      return;
    }

    this.filteredSuppliers = this.suppliers.filter((item) =>
      item.name.toLowerCase().includes(value) ||
      item.supplierId.toLowerCase().includes(value) ||
      item.company.toLowerCase().includes(value) ||
      item.drugs.toLowerCase().includes(value)
    );
  }

  loadSuppliers(): void {
    this.loading = true;
    this.errorMessage = '';
    this.supplierService.getSuppliers().subscribe({
      next: (response) => {
        this.suppliers = (response as any[]).map((item: any) => ({
          ...item,
          supplierId: item.supplierId ?? item.supplierID ?? '',
          company: item.company ?? 'Unknown',
          address: item.address ?? 'Unknown',
          status: item.status ?? 'Active',
          drugs: item.drugs ?? item.drugsAvailable ?? ''
        }));
        this.filteredSuppliers = [...this.suppliers];
        this.loading = false;
      },
      error: () => {
        this.loading = false;
        this.errorMessage = 'Unable to load suppliers right now.';
      }
    });
  }

  submitSupplier(): void {
    if (this.supplierForm.invalid) {
      this.supplierForm.markAllAsTouched();
      this.errorMessage = 'Please correct the highlighted fields before saving.';
      return;
    }

    this.loading = true;
    this.errorMessage = '';
    this.successMessage = '';

    const payload = this.supplierForm.value;

    if (this.isEditing && this.selectedSupplier?._id) {
      this.supplierService.updateSupplier(this.selectedSupplier._id, payload).subscribe({
        next: () => {
          this.loading = false;
          this.successMessage = 'Supplier updated successfully.';
          this.resetForm();
          this.loadSuppliers();
        },
        error: () => {
          this.loading = false;
          this.errorMessage = 'Unable to update supplier. Please try again.';
        }
      });
      return;
    }

    this.supplierService.createSupplier(payload).subscribe({
      next: () => {
        this.loading = false;
        this.successMessage = 'Supplier added successfully.';
        this.resetForm();
        this.loadSuppliers();
      },
      error: () => {
        this.loading = false;
        this.errorMessage = 'Unable to add supplier. Please try again.';
      }
    });
  }

  addSupplier(): void {
    this.isEditing = false;
    this.selectedSupplier = null;
    this.resetForm();
  }

  editSupplier(supplier: Supplier): void {
    this.isEditing = true;
    this.selectedSupplier = supplier;
    this.supplierForm.patchValue({
      supplierId: supplier.supplierId,
      name: supplier.name,
      email: supplier.email,
      contact: supplier.contact,
      address: supplier.address,
      company: supplier.company,
      drugs: supplier.drugs,
      status: supplier.status
    });
  }

  deleteSupplier(supplier: Supplier): void {
    const ok = confirm(`Delete ${supplier.name}?`);
    if (!ok || !supplier._id) {
      return;
    }

    this.loading = true;
    this.errorMessage = '';
    this.successMessage = '';
    this.supplierService.deleteSupplier(supplier._id).subscribe({
      next: () => {
        this.loading = false;
        this.successMessage = 'Supplier deleted successfully.';
        this.loadSuppliers();
      },
      error: () => {
        this.loading = false;
        this.errorMessage = 'Unable to delete supplier. Please try again.';
      }
    });
  }

  refresh(): void {
    this.loadSuppliers();
  }

  private resetForm(): void {
    this.supplierForm.reset({
      supplierId: '',
      name: '',
      email: '',
      contact: '',
      address: '',
      company: '',
      drugs: '',
      status: 'Active'
    });
    this.isEditing = false;
    this.selectedSupplier = null;
  }
}
