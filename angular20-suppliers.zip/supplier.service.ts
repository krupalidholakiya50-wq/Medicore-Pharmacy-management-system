import { Injectable, inject } from '@angular/core';
import { Observable } from 'rxjs';
import { Supplier } from './supplier.model';
import { ApiService } from './api.service';

@Injectable({ providedIn: 'root' })
export class SupplierService {
  private readonly api = inject(ApiService);

  getSuppliers(): Observable<Supplier[]> {
    return this.api.get<Supplier[]>('/suppliers');
  }

  createSupplier(payload: Partial<Supplier>): Observable<{ message: string; supplier?: Supplier }> {
    return this.api.post<{ message: string; supplier?: Supplier }>('/suppliers', payload);
  }

  updateSupplier(id: string, payload: Partial<Supplier>): Observable<{ message: string }> {
    return this.api.put<{ message: string }>(`/suppliers/${id}`, payload);
  }

  deleteSupplier(id: string): Observable<{ message: string }> {
    return this.api.delete<{ message: string }>(`/suppliers/${id}`);
  }
}
