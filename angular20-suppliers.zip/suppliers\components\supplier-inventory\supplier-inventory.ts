import { Component } from '@angular/core';

@Component({
  selector: 'app-supplier-inventory',
  imports: [],
  templateUrl: './supplier-inventory.html',
  styleUrl: './supplier-inventory.css',
})
export class SupplierInventory {}
