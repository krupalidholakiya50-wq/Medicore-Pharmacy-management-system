import { Component } from '@angular/core';

@Component({
  selector: 'app-supplier-search',
  imports: [],
  templateUrl: './supplier-search.html',
  styleUrl: './supplier-search.css',
})
export class SupplierSearch {}
