import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SupplierSearch } from './supplier-search';

describe('SupplierSearch', () => {
  let component: SupplierSearch;
  let fixture: ComponentFixture<SupplierSearch>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [SupplierSearch],
    }).compileComponents();

    fixture = TestBed.createComponent(SupplierSearch);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
